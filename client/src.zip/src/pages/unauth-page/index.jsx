function UnauthPage() {
  return <div>You don't have access to view this page</div>;
}

export default UnauthPage;
